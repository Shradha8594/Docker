// const API_BASE_URL = "http://3.87.228.149:84";
const API_BASE_URL = "http://3.80.143.36:84";
// export default API_BASE_URL;
// const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://backend";
/// export default API_BASE_URL;
//const API_BASE_URL = "REACT_APP_API_BASE_URL_PLACEHOLDER";
export default API_BASE_URL;

